#include "ATMInterface.h"


ATMInterface::ATMInterface(void)
{
}


ATMInterface::~ATMInterface(void)
{
}
