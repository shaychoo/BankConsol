#ifndef BUSINESSACCOUNT_H
#define BUSINESSACCOUNT_H
#include "Account.h"

class BusinessAccount : public Account
{
public:
    BusinessAccount();
	
};

#endif // BUSINESSACCOUNT_H
