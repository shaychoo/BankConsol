#pragma once
#include "bankinterface.h"
class ATMInterface :
	public BankInterface
{
public:
	ATMInterface(void);
	~ATMInterface(void);
};

