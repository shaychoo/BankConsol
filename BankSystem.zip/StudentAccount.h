#ifndef STUDENTACCOUNT_H
#define STUDENTACCOUNT_H
#include "account.h"

class StudentAccount : public Account
{
public:
    StudentAccount();
};

#endif // STUDENTACCOUNT_H
