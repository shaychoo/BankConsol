#define NOT_ENOUGHT_CREDIT "You'r Credit is too low to do this operation"
#define ACCOUNT_IS_NOT_ACTIVE "Sorry ,this Account isn't active."
#define ACCOUNT_TRANSFER_TO_IS_NOT_ACTIVE "Sorry ,the Account you try to transfer to isn't active."
#define ACCOUNT_HAVE_NO_MONEY "There is no enought money in this account"
#define BALANCE_IS_NOT_ZERO "The balance is not zero"


