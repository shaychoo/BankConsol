#include <iostream>
#include "PlatinumClient.h"
#include "BusinessAccount.h"
#include "StudentAccount.h"



void main(void)
{
	int a;
	Account* a1 = new BusinessAccount();
	Account* a2 = new BusinessAccount();
	Account* a3 = new StudentAccount();
	Account* a4 = new StudentAccount();
	
	
}
