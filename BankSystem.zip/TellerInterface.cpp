#include "TellerInterface.h"


TellerInterface::TellerInterface(void)
{
}


TellerInterface::~TellerInterface(void)
{
}
