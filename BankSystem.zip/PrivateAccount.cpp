#include "privateaccount.h"

PrivateAccount::PrivateAccount(): Account(4.5,-5000){}
