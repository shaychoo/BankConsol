// Clents.h
// This file used only for easier include 
#include "Client.h"
#include "RegularClient.h"
#include "GoldClient.h"
#include "PlatinumClient.h"