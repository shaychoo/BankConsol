#include "ManagerInterface.h"


ManagerInterface::ManagerInterface(void)
{
}


ManagerInterface::~ManagerInterface(void)
{
}
