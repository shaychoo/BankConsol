#include "PlatinumClient.h"


PlatinumClient::PlatinumClient(string id, string Name, string birthDate, string PhoneNumber,string Address):Client(id, Name, birthDate, PhoneNumber,Address){ }



PlatinumClient::~PlatinumClient(void)
{
}
