#include "StudentAccount.h"

StudentAccount::StudentAccount():Account(0.0,0) // firstVar - Commision , second - Credit
{}
