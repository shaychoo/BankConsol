#pragma once
#include "Accounts.h"
#include "Clients.h"
#include <map>
#include <iostream>
using namespace std;

 // typedef map<string,float> StringFloatMap;
 // StringFloatMap coll;

class BankDB
{
private:
    static bool instanceFlag;
    static BankDB *single;
    BankDB();
//	map<int, Account*> accounts;
//	map<string, Client*> clients;

public:
    static BankDB* getDB();
    ~BankDB();





};