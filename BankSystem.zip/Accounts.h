// Accounts.h
// This file used only for easier include 
#include "Account.h"
#include "StudentAccount.h"
#include "PrivateAccount.h"
#include "BusinessAccount.h"