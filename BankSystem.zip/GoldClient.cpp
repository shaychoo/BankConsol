#include "goldclient.h"

GoldClient::GoldClient(string id, string Name, string birthDate, string PhoneNumber,string Address):Client(id, Name, birthDate, PhoneNumber,Address){ }


