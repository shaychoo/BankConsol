#include "RegularClient.h"


RegularClient::RegularClient(string id, string Name, string birthDate, string PhoneNumber,string Address):Client(id, Name, birthDate, PhoneNumber,Address){ }


RegularClient::~RegularClient(void)
{
}
