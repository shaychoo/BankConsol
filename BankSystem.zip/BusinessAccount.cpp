#include "BusinessAccount.h"

BusinessAccount::BusinessAccount(): Account(6.5,-10000)
{
}
