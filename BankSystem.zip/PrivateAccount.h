#ifndef PRIVATEACCOUNT_H
#define PRIVATEACCOUNT_H
#include "account.h"

class PrivateAccount : public Account
{
public:
    PrivateAccount();
};

#endif // PRIVATEACCOUNT_H
