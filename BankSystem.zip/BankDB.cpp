#include "BankDB.h"

bool BankDB::instanceFlag = false;
BankDB* BankDB::single = NULL;

// Bank databse constructor
BankDB::BankDB(void) {}

//Deconstructor 
BankDB::~BankDB(void)
{
	instanceFlag = false;
}




BankDB* BankDB::getDB()
{
    if(! instanceFlag)
    {
        single = new BankDB();
        instanceFlag = true;
        return single;
    }
    else
    {
        return single;
    }
}


