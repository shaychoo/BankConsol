#pragma once
#include "bankinterface.h"
#include "Accounts.h"
#include "Clients.h"
class TellerInterface :
	public BankInterface
{
public:
	TellerInterface(void);
	~TellerInterface(void);
	void CreateNewClient(Client*);


};

